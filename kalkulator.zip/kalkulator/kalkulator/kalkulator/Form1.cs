﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kalkulator
{
    public partial class Kalkulator : Form
    {
        double results = 0;
        string operation = "";
        bool enter_value = false;

        public Kalkulator()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void zwykłyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 350;
            textBox1.Width = 278;
        }

        private void programistyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 644;
            textBox1.Width = 611;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void konwersjaJednostekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 644;
            textBox1.Width = 611;
        }

        private void multiplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 990;
            textBox1.Width = 611;
            textBox1.Focus();          
        }

        private void button_Click(object sender, EventArgs e)
        {
            if((textBox1.Text == "0") || (enter_value))
                
                textBox1.Text = "";
                
            enter_value = false;
            Button num = (Button)sender;
            if(num.Text == ".")
            {
                if (!textBox1.Text.Contains("."))
                    textBox1.Text = textBox1.Text + num.Text;
            }
            else
                textBox1.Text = textBox1.Text + num.Text;
        }

        private void b_CE_Click(object sender, EventArgs e) // czyszczenie wyswietlacza
        {
            textBox1.Text = "0";
            lblShowOP.Text = "";
        }

        private void b_C_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            lblShowOP.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text.Length > 0 )
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1, 1); // usuwa nam o jedno miejsce w lewo
            }

            if (textBox1.Text=="")
            {
                textBox1.Text = "0"; // wyświetla nam zero
            }

        }

        private void Arytmetyczne_Operacje(object sender, EventArgs e)
        {
            try
            {
                Button num = (Button)sender; //lblShowOP jest przydatny do wyswietlania tego co juz mamy w lewym gornym rogu
                operation = num.Text;
                results = Double.Parse(textBox1.Text);
                textBox1.Text = "";
                lblShowOP.Text = System.Convert.ToString(results) + " " + operation;
            }

            catch(Exception)
            {
                textBox1.Text = "Błąd!";
            }
            
        }

        private void zapomnialem_o_nich_mialy_byc_w_arytmetycznych_operacjach(object sender, EventArgs e) // zapomnialem o modulo i Exp
        {
            Button num = (Button)sender;
            operation = num.Text;
            results = Double.Parse(textBox1.Text);
            textBox1.Text = "";
            lblShowOP.Text = System.Convert.ToString(results) + " " + operation;
        }

        private void b_wynik_Click(object sender, EventArgs e)
        {
            lblShowOP.Text = "";
            switch(operation)
            {
                case "+":
                    textBox1.Text = (results + float.Parse(textBox1.Text)).ToString();
                    break;

                case "-":
                    textBox1.Text = (results - Double.Parse(textBox1.Text)).ToString();
                    break;

                case "*":
                    textBox1.Text = (results * Double.Parse(textBox1.Text)).ToString();
                    break;

                case "/":
                    textBox1.Text = (results / Double.Parse(textBox1.Text)).ToString();
                    break;

                case "mod":
                    textBox1.Text = (results % Double.Parse(textBox1.Text)).ToString();
                    break;

                case "Exp":
                    double i = Double.Parse(textBox1.Text);
                    double q;
                    q = (results);
                    textBox1.Text = Math.Exp(i*Math.Log(q*4)).ToString();
                    break;

            }
        }

        private void b_pi_Click(object sender, EventArgs e)
        {
            textBox1.Text = "3,14159265358979323846264"; // liczba Pi
        }

        private void b_log_Click(object sender, EventArgs e)
        {
            double ilog = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Logarytm" + "(" + (textBox1.Text) + ")");
            ilog = Math.Log10(ilog); // Logarytm
            textBox1.Text = System.Convert.ToString(ilog);
        }

        private void b_sqrt_Click(object sender, EventArgs e)
        {

            double sqrt = Double.Parse(textBox1.Text); // sqrt pierwiastek
            lblShowOP.Text = System.Convert.ToString("Pierwiastek" + "(" + (textBox1.Text) + ")");
            sqrt = Math.Sqrt(sqrt); // Logarytm
            textBox1.Text = System.Convert.ToString(sqrt);
        }

        private void b_sinh_Click(object sender, EventArgs e)
        {

            double sinush = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Sinh" + "(" + (textBox1.Text) + ")");
            sinush = Math.Sinh(sinush); 
            textBox1.Text = System.Convert.ToString(sinush);
        }

        private void b_cosh_Click(object sender, EventArgs e)
        {
            double cosinush = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Cosh" + "(" + (textBox1.Text) + ")");
            cosinush = Math.Cosh(cosinush); 
            textBox1.Text = System.Convert.ToString(cosinush);
        }

        private void b_tanh_Click(object sender, EventArgs e)
        {
            double tanh = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Tanh" + "(" + (textBox1.Text) + ")");
            tanh = Math.Cosh(tanh); 
            textBox1.Text = System.Convert.ToString(tanh);
        }

        private void b_sin_Click(object sender, EventArgs e)
        {
            double sinus = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Sinus" + "(" + (textBox1.Text) + ")");
            sinus = Math.Sin(sinus);
            textBox1.Text = System.Convert.ToString(sinus);
        }

        private void b_cos_Click(object sender, EventArgs e)
        {
            double cosinus = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Cosinus" + "(" + (textBox1.Text) + ")");
            cosinus = Math.Cos(cosinus);
            textBox1.Text = System.Convert.ToString(cosinus);
        }

        private void b_tan_Click(object sender, EventArgs e)
        {
            double tan = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Tangens" + "(" + (textBox1.Text) + ")");
            tan = Math.Tan(tan);
            textBox1.Text = System.Convert.ToString(tan);
        }

        private void b_bin_Click(object sender, EventArgs e)
        {
            int pomoc = int.Parse(textBox1.Text); // binarny
            textBox1.Text = System.Convert.ToString(pomoc, 2);
        }

        private void b_hex_Click(object sender, EventArgs e)
        {
            int pomoc = int.Parse(textBox1.Text); // szesnastkowy
            textBox1.Text = System.Convert.ToString(pomoc, 16);
        }

        private void b_oct_Click(object sender, EventArgs e)
        {
            int pomoc = int.Parse(textBox1.Text); // osemkowy
            textBox1.Text = System.Convert.ToString(pomoc, 8);
        }

        private void b_dec_Click(object sender, EventArgs e)
        {
            int pomoc = int.Parse(textBox1.Text); // dziesietny
            textBox1.Text = System.Convert.ToString(pomoc);
        }

        private void b_x2_Click(object sender, EventArgs e)
        {
            double kwadrat;
            kwadrat = Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox1.Text);
            textBox1.Text = System.Convert.ToString(kwadrat);
        }

        private void b_x3_Click(object sender, EventArgs e)
        {
            double do_szescianu;
            do_szescianu = Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox1.Text);
            textBox1.Text = System.Convert.ToString(do_szescianu);
        }

        private void b_1x_Click(object sender, EventArgs e)
        {
            double pomocny;
            pomocny = Convert.ToDouble(1.0 / Convert.ToDouble(textBox1.Text));
            textBox1.Text = System.Convert.ToString(pomocny);
        }

        private void b_logx_Click(object sender, EventArgs e)
        {
            double ilog = Double.Parse(textBox1.Text);
            lblShowOP.Text = System.Convert.ToString("Logarytm n " + "(" + (textBox1.Text) + ")");
            ilog = Math.Log(ilog); // Logarytm
            textBox1.Text = System.Convert.ToString(ilog);
        }

        private void b_procent_Click(object sender, EventArgs e)
        {
            double procenty;
            procenty = Convert.ToDouble(textBox1.Text) / Convert.ToDouble(100);
            textBox1.Text = System.Convert.ToString(procenty);
        }

        private void button_wielo_Click(object sender, EventArgs e)
        {
            int wielokrotnosc;
            wielokrotnosc = Convert.ToInt32(txt_Multiply.Text);
            for(int i =1; i<26;i++)
            {
                list_wielokrotnosc.Items.Add(i + "x" + wielokrotnosc + "=" + wielokrotnosc * i );
            }
        }

        private void button_reset_Click(object sender, EventArgs e)
        {
            txt_Multiply.Clear();
            list_wielokrotnosc.Items.Clear();
        }

        private void list_wielokrotnosc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void b_plusminus_Click(object sender, EventArgs e)
        {
            double plusminus;
            plusminus = Convert.ToDouble(textBox1.Text) * Convert.ToDouble(-1);
            textBox1.Text = System.Convert.ToString(plusminus);
        }

        private void wyjścieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }


}


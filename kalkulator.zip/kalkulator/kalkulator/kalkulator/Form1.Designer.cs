﻿namespace kalkulator
{
    partial class Kalkulator
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kalkulator));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.rodzajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zwykłyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programistyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.konwersjaJednostekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wyjścieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.b_strzalka = new System.Windows.Forms.Button();
            this.b_CE = new System.Windows.Forms.Button();
            this.b_C = new System.Windows.Forms.Button();
            this.b_plusminus = new System.Windows.Forms.Button();
            this.b_minus = new System.Windows.Forms.Button();
            this.b_6 = new System.Windows.Forms.Button();
            this.b_5 = new System.Windows.Forms.Button();
            this.b_4 = new System.Windows.Forms.Button();
            this.b_mnozenie = new System.Windows.Forms.Button();
            this.b_3 = new System.Windows.Forms.Button();
            this.b_2 = new System.Windows.Forms.Button();
            this.b_1 = new System.Windows.Forms.Button();
            this.b_podziel = new System.Windows.Forms.Button();
            this.b_wynik = new System.Windows.Forms.Button();
            this.b_kropka = new System.Windows.Forms.Button();
            this.b_0 = new System.Windows.Forms.Button();
            this.b_plus = new System.Windows.Forms.Button();
            this.b_9 = new System.Windows.Forms.Button();
            this.b_8 = new System.Windows.Forms.Button();
            this.b_7 = new System.Windows.Forms.Button();
            this.b_x3 = new System.Windows.Forms.Button();
            this.b_dec = new System.Windows.Forms.Button();
            this.b_sin = new System.Windows.Forms.Button();
            this.b_sinh = new System.Windows.Forms.Button();
            this.b_procent = new System.Windows.Forms.Button();
            this.b_oct = new System.Windows.Forms.Button();
            this.b_mod = new System.Windows.Forms.Button();
            this.b_exp = new System.Windows.Forms.Button();
            this.b_logx = new System.Windows.Forms.Button();
            this.b_hex = new System.Windows.Forms.Button();
            this.b_tan = new System.Windows.Forms.Button();
            this.b_tanh = new System.Windows.Forms.Button();
            this.b_1x = new System.Windows.Forms.Button();
            this.b_bin = new System.Windows.Forms.Button();
            this.b_cos = new System.Windows.Forms.Button();
            this.b_cosh = new System.Windows.Forms.Button();
            this.b_x2 = new System.Windows.Forms.Button();
            this.b_sqrt = new System.Windows.Forms.Button();
            this.b_log = new System.Windows.Forms.Button();
            this.b_pi = new System.Windows.Forms.Button();
            this.lblShowOP = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Multiply = new System.Windows.Forms.TextBox();
            this.button_reset = new System.Windows.Forms.Button();
            this.button_wielo = new System.Windows.Forms.Button();
            this.list_wielokrotnosc = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rodzajToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(334, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // rodzajToolStripMenuItem
            // 
            this.rodzajToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zwykłyToolStripMenuItem,
            this.programistyToolStripMenuItem,
            this.konwersjaJednostekToolStripMenuItem,
            this.multiplicationToolStripMenuItem,
            this.wyjścieToolStripMenuItem});
            this.rodzajToolStripMenuItem.Name = "rodzajToolStripMenuItem";
            this.rodzajToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.rodzajToolStripMenuItem.Text = "Rodzaj";
            // 
            // zwykłyToolStripMenuItem
            // 
            this.zwykłyToolStripMenuItem.Name = "zwykłyToolStripMenuItem";
            this.zwykłyToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.zwykłyToolStripMenuItem.Text = "Zwykły";
            this.zwykłyToolStripMenuItem.Click += new System.EventHandler(this.zwykłyToolStripMenuItem_Click);
            // 
            // programistyToolStripMenuItem
            // 
            this.programistyToolStripMenuItem.Name = "programistyToolStripMenuItem";
            this.programistyToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.programistyToolStripMenuItem.Text = "Programisty";
            this.programistyToolStripMenuItem.Click += new System.EventHandler(this.programistyToolStripMenuItem_Click);
            // 
            // konwersjaJednostekToolStripMenuItem
            // 
            this.konwersjaJednostekToolStripMenuItem.Name = "konwersjaJednostekToolStripMenuItem";
            this.konwersjaJednostekToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.konwersjaJednostekToolStripMenuItem.Text = "Konwersja jednostek";
            this.konwersjaJednostekToolStripMenuItem.Click += new System.EventHandler(this.konwersjaJednostekToolStripMenuItem_Click);
            // 
            // multiplicationToolStripMenuItem
            // 
            this.multiplicationToolStripMenuItem.Name = "multiplicationToolStripMenuItem";
            this.multiplicationToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.multiplicationToolStripMenuItem.Text = "Wielokrotność";
            this.multiplicationToolStripMenuItem.Click += new System.EventHandler(this.multiplicationToolStripMenuItem_Click);
            // 
            // wyjścieToolStripMenuItem
            // 
            this.wyjścieToolStripMenuItem.Name = "wyjścieToolStripMenuItem";
            this.wyjścieToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.wyjścieToolStripMenuItem.Text = "Wyjście";
            this.wyjścieToolStripMenuItem.Click += new System.EventHandler(this.wyjścieToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(12, 24);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(278, 40);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // b_strzalka
            // 
            this.b_strzalka.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_strzalka.Location = new System.Drawing.Point(12, 73);
            this.b_strzalka.Name = "b_strzalka";
            this.b_strzalka.Size = new System.Drawing.Size(65, 63);
            this.b_strzalka.TabIndex = 2;
            this.b_strzalka.Text = "<-";
            this.b_strzalka.UseVisualStyleBackColor = true;
            this.b_strzalka.Click += new System.EventHandler(this.button1_Click);
            // 
            // b_CE
            // 
            this.b_CE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_CE.Location = new System.Drawing.Point(83, 73);
            this.b_CE.Name = "b_CE";
            this.b_CE.Size = new System.Drawing.Size(65, 63);
            this.b_CE.TabIndex = 3;
            this.b_CE.Text = "CE";
            this.b_CE.UseVisualStyleBackColor = true;
            this.b_CE.Click += new System.EventHandler(this.b_CE_Click);
            // 
            // b_C
            // 
            this.b_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_C.Location = new System.Drawing.Point(154, 73);
            this.b_C.Name = "b_C";
            this.b_C.Size = new System.Drawing.Size(65, 63);
            this.b_C.TabIndex = 4;
            this.b_C.Text = "C";
            this.b_C.UseVisualStyleBackColor = true;
            this.b_C.Click += new System.EventHandler(this.b_C_Click);
            // 
            // b_plusminus
            // 
            this.b_plusminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_plusminus.Location = new System.Drawing.Point(225, 73);
            this.b_plusminus.Name = "b_plusminus";
            this.b_plusminus.Size = new System.Drawing.Size(65, 63);
            this.b_plusminus.TabIndex = 5;
            this.b_plusminus.Text = "±";
            this.b_plusminus.UseVisualStyleBackColor = true;
            this.b_plusminus.Click += new System.EventHandler(this.b_plusminus_Click);
            // 
            // b_minus
            // 
            this.b_minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_minus.Location = new System.Drawing.Point(225, 211);
            this.b_minus.Name = "b_minus";
            this.b_minus.Size = new System.Drawing.Size(65, 63);
            this.b_minus.TabIndex = 9;
            this.b_minus.Text = "-";
            this.b_minus.UseVisualStyleBackColor = true;
            this.b_minus.Click += new System.EventHandler(this.Arytmetyczne_Operacje);
            // 
            // b_6
            // 
            this.b_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_6.Location = new System.Drawing.Point(154, 211);
            this.b_6.Name = "b_6";
            this.b_6.Size = new System.Drawing.Size(65, 63);
            this.b_6.TabIndex = 8;
            this.b_6.Text = "6";
            this.b_6.UseVisualStyleBackColor = true;
            this.b_6.Click += new System.EventHandler(this.button_Click);
            // 
            // b_5
            // 
            this.b_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_5.Location = new System.Drawing.Point(83, 211);
            this.b_5.Name = "b_5";
            this.b_5.Size = new System.Drawing.Size(65, 63);
            this.b_5.TabIndex = 7;
            this.b_5.Text = "5";
            this.b_5.UseVisualStyleBackColor = true;
            this.b_5.Click += new System.EventHandler(this.button_Click);
            // 
            // b_4
            // 
            this.b_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_4.Location = new System.Drawing.Point(12, 211);
            this.b_4.Name = "b_4";
            this.b_4.Size = new System.Drawing.Size(65, 63);
            this.b_4.TabIndex = 6;
            this.b_4.Text = "4";
            this.b_4.UseVisualStyleBackColor = true;
            this.b_4.Click += new System.EventHandler(this.button_Click);
            // 
            // b_mnozenie
            // 
            this.b_mnozenie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_mnozenie.Location = new System.Drawing.Point(225, 280);
            this.b_mnozenie.Name = "b_mnozenie";
            this.b_mnozenie.Size = new System.Drawing.Size(65, 63);
            this.b_mnozenie.TabIndex = 13;
            this.b_mnozenie.Text = "*";
            this.b_mnozenie.UseVisualStyleBackColor = true;
            this.b_mnozenie.Click += new System.EventHandler(this.Arytmetyczne_Operacje);
            // 
            // b_3
            // 
            this.b_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_3.Location = new System.Drawing.Point(154, 280);
            this.b_3.Name = "b_3";
            this.b_3.Size = new System.Drawing.Size(65, 63);
            this.b_3.TabIndex = 12;
            this.b_3.Text = "3";
            this.b_3.UseVisualStyleBackColor = true;
            this.b_3.Click += new System.EventHandler(this.button_Click);
            // 
            // b_2
            // 
            this.b_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_2.Location = new System.Drawing.Point(83, 280);
            this.b_2.Name = "b_2";
            this.b_2.Size = new System.Drawing.Size(65, 63);
            this.b_2.TabIndex = 11;
            this.b_2.Text = "2";
            this.b_2.UseVisualStyleBackColor = true;
            this.b_2.Click += new System.EventHandler(this.button_Click);
            // 
            // b_1
            // 
            this.b_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_1.Location = new System.Drawing.Point(12, 280);
            this.b_1.Name = "b_1";
            this.b_1.Size = new System.Drawing.Size(65, 63);
            this.b_1.TabIndex = 10;
            this.b_1.Text = "1";
            this.b_1.UseVisualStyleBackColor = true;
            this.b_1.Click += new System.EventHandler(this.button_Click);
            // 
            // b_podziel
            // 
            this.b_podziel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_podziel.Location = new System.Drawing.Point(225, 349);
            this.b_podziel.Name = "b_podziel";
            this.b_podziel.Size = new System.Drawing.Size(65, 63);
            this.b_podziel.TabIndex = 17;
            this.b_podziel.Text = "/";
            this.b_podziel.UseVisualStyleBackColor = true;
            this.b_podziel.Click += new System.EventHandler(this.Arytmetyczne_Operacje);
            // 
            // b_wynik
            // 
            this.b_wynik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_wynik.Location = new System.Drawing.Point(154, 349);
            this.b_wynik.Name = "b_wynik";
            this.b_wynik.Size = new System.Drawing.Size(65, 63);
            this.b_wynik.TabIndex = 16;
            this.b_wynik.Text = "=";
            this.b_wynik.UseVisualStyleBackColor = true;
            this.b_wynik.Click += new System.EventHandler(this.b_wynik_Click);
            // 
            // b_kropka
            // 
            this.b_kropka.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_kropka.Location = new System.Drawing.Point(83, 349);
            this.b_kropka.Name = "b_kropka";
            this.b_kropka.Size = new System.Drawing.Size(65, 63);
            this.b_kropka.TabIndex = 15;
            this.b_kropka.Text = ".";
            this.b_kropka.UseVisualStyleBackColor = true;
            this.b_kropka.Click += new System.EventHandler(this.button_Click);
            // 
            // b_0
            // 
            this.b_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_0.Location = new System.Drawing.Point(12, 349);
            this.b_0.Name = "b_0";
            this.b_0.Size = new System.Drawing.Size(65, 63);
            this.b_0.TabIndex = 14;
            this.b_0.Text = "0";
            this.b_0.UseVisualStyleBackColor = true;
            this.b_0.Click += new System.EventHandler(this.button_Click);
            // 
            // b_plus
            // 
            this.b_plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_plus.Location = new System.Drawing.Point(225, 142);
            this.b_plus.Name = "b_plus";
            this.b_plus.Size = new System.Drawing.Size(65, 63);
            this.b_plus.TabIndex = 37;
            this.b_plus.Text = "+";
            this.b_plus.UseVisualStyleBackColor = true;
            this.b_plus.Click += new System.EventHandler(this.Arytmetyczne_Operacje);
            // 
            // b_9
            // 
            this.b_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_9.Location = new System.Drawing.Point(154, 142);
            this.b_9.Name = "b_9";
            this.b_9.Size = new System.Drawing.Size(65, 63);
            this.b_9.TabIndex = 36;
            this.b_9.Text = "9";
            this.b_9.UseVisualStyleBackColor = true;
            this.b_9.Click += new System.EventHandler(this.button_Click);
            // 
            // b_8
            // 
            this.b_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_8.Location = new System.Drawing.Point(83, 142);
            this.b_8.Name = "b_8";
            this.b_8.Size = new System.Drawing.Size(65, 63);
            this.b_8.TabIndex = 35;
            this.b_8.Text = "8";
            this.b_8.UseVisualStyleBackColor = true;
            this.b_8.Click += new System.EventHandler(this.button_Click);
            // 
            // b_7
            // 
            this.b_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_7.Location = new System.Drawing.Point(12, 142);
            this.b_7.Name = "b_7";
            this.b_7.Size = new System.Drawing.Size(65, 63);
            this.b_7.TabIndex = 34;
            this.b_7.Text = "7";
            this.b_7.UseVisualStyleBackColor = true;
            this.b_7.Click += new System.EventHandler(this.button_Click);
            // 
            // b_x3
            // 
            this.b_x3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_x3.Location = new System.Drawing.Point(558, 142);
            this.b_x3.Name = "b_x3";
            this.b_x3.Size = new System.Drawing.Size(65, 63);
            this.b_x3.TabIndex = 57;
            this.b_x3.Text = "x^3";
            this.b_x3.UseVisualStyleBackColor = true;
            this.b_x3.Click += new System.EventHandler(this.b_x3_Click);
            // 
            // b_dec
            // 
            this.b_dec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_dec.Location = new System.Drawing.Point(487, 142);
            this.b_dec.Name = "b_dec";
            this.b_dec.Size = new System.Drawing.Size(65, 63);
            this.b_dec.TabIndex = 56;
            this.b_dec.Text = "Dec";
            this.b_dec.UseVisualStyleBackColor = true;
            this.b_dec.Click += new System.EventHandler(this.b_dec_Click);
            // 
            // b_sin
            // 
            this.b_sin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_sin.Location = new System.Drawing.Point(416, 142);
            this.b_sin.Name = "b_sin";
            this.b_sin.Size = new System.Drawing.Size(65, 63);
            this.b_sin.TabIndex = 55;
            this.b_sin.Text = "Sin";
            this.b_sin.UseVisualStyleBackColor = true;
            this.b_sin.Click += new System.EventHandler(this.b_sin_Click);
            // 
            // b_sinh
            // 
            this.b_sinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_sinh.Location = new System.Drawing.Point(345, 142);
            this.b_sinh.Name = "b_sinh";
            this.b_sinh.Size = new System.Drawing.Size(65, 63);
            this.b_sinh.TabIndex = 54;
            this.b_sinh.Text = "Sinh";
            this.b_sinh.UseVisualStyleBackColor = true;
            this.b_sinh.Click += new System.EventHandler(this.b_sinh_Click);
            // 
            // b_procent
            // 
            this.b_procent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_procent.Location = new System.Drawing.Point(558, 349);
            this.b_procent.Name = "b_procent";
            this.b_procent.Size = new System.Drawing.Size(65, 63);
            this.b_procent.TabIndex = 53;
            this.b_procent.Text = "%";
            this.b_procent.UseVisualStyleBackColor = true;
            this.b_procent.Click += new System.EventHandler(this.b_procent_Click);
            // 
            // b_oct
            // 
            this.b_oct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_oct.Location = new System.Drawing.Point(487, 349);
            this.b_oct.Name = "b_oct";
            this.b_oct.Size = new System.Drawing.Size(65, 63);
            this.b_oct.TabIndex = 52;
            this.b_oct.Text = "Oct";
            this.b_oct.UseVisualStyleBackColor = true;
            this.b_oct.Click += new System.EventHandler(this.b_oct_Click);
            // 
            // b_mod
            // 
            this.b_mod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_mod.Location = new System.Drawing.Point(416, 349);
            this.b_mod.Name = "b_mod";
            this.b_mod.Size = new System.Drawing.Size(65, 63);
            this.b_mod.TabIndex = 51;
            this.b_mod.Text = "mod";
            this.b_mod.UseVisualStyleBackColor = true;
            this.b_mod.Click += new System.EventHandler(this.zapomnialem_o_nich_mialy_byc_w_arytmetycznych_operacjach);
            // 
            // b_exp
            // 
            this.b_exp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_exp.Location = new System.Drawing.Point(345, 349);
            this.b_exp.Name = "b_exp";
            this.b_exp.Size = new System.Drawing.Size(65, 63);
            this.b_exp.TabIndex = 50;
            this.b_exp.Text = "Exp";
            this.b_exp.UseVisualStyleBackColor = true;
            this.b_exp.Click += new System.EventHandler(this.zapomnialem_o_nich_mialy_byc_w_arytmetycznych_operacjach);
            // 
            // b_logx
            // 
            this.b_logx.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_logx.Location = new System.Drawing.Point(558, 280);
            this.b_logx.Name = "b_logx";
            this.b_logx.Size = new System.Drawing.Size(65, 63);
            this.b_logx.TabIndex = 49;
            this.b_logx.Text = "Ln x";
            this.b_logx.UseVisualStyleBackColor = true;
            this.b_logx.Click += new System.EventHandler(this.b_logx_Click);
            // 
            // b_hex
            // 
            this.b_hex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_hex.Location = new System.Drawing.Point(487, 280);
            this.b_hex.Name = "b_hex";
            this.b_hex.Size = new System.Drawing.Size(65, 63);
            this.b_hex.TabIndex = 48;
            this.b_hex.Text = "Hex";
            this.b_hex.UseVisualStyleBackColor = true;
            this.b_hex.Click += new System.EventHandler(this.b_hex_Click);
            // 
            // b_tan
            // 
            this.b_tan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_tan.Location = new System.Drawing.Point(416, 280);
            this.b_tan.Name = "b_tan";
            this.b_tan.Size = new System.Drawing.Size(65, 63);
            this.b_tan.TabIndex = 47;
            this.b_tan.Text = "Tan";
            this.b_tan.UseVisualStyleBackColor = true;
            this.b_tan.Click += new System.EventHandler(this.b_tan_Click);
            // 
            // b_tanh
            // 
            this.b_tanh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_tanh.Location = new System.Drawing.Point(345, 280);
            this.b_tanh.Name = "b_tanh";
            this.b_tanh.Size = new System.Drawing.Size(65, 63);
            this.b_tanh.TabIndex = 46;
            this.b_tanh.Text = "Tanh";
            this.b_tanh.UseVisualStyleBackColor = true;
            this.b_tanh.Click += new System.EventHandler(this.b_tanh_Click);
            // 
            // b_1x
            // 
            this.b_1x.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_1x.Location = new System.Drawing.Point(558, 211);
            this.b_1x.Name = "b_1x";
            this.b_1x.Size = new System.Drawing.Size(65, 63);
            this.b_1x.TabIndex = 45;
            this.b_1x.Text = "1/x";
            this.b_1x.UseVisualStyleBackColor = true;
            this.b_1x.Click += new System.EventHandler(this.b_1x_Click);
            // 
            // b_bin
            // 
            this.b_bin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_bin.Location = new System.Drawing.Point(487, 211);
            this.b_bin.Name = "b_bin";
            this.b_bin.Size = new System.Drawing.Size(65, 63);
            this.b_bin.TabIndex = 44;
            this.b_bin.Text = "Bin";
            this.b_bin.UseVisualStyleBackColor = true;
            this.b_bin.Click += new System.EventHandler(this.b_bin_Click);
            // 
            // b_cos
            // 
            this.b_cos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_cos.Location = new System.Drawing.Point(416, 211);
            this.b_cos.Name = "b_cos";
            this.b_cos.Size = new System.Drawing.Size(65, 63);
            this.b_cos.TabIndex = 43;
            this.b_cos.Text = "Cos";
            this.b_cos.UseVisualStyleBackColor = true;
            this.b_cos.Click += new System.EventHandler(this.b_cos_Click);
            // 
            // b_cosh
            // 
            this.b_cosh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_cosh.Location = new System.Drawing.Point(345, 211);
            this.b_cosh.Name = "b_cosh";
            this.b_cosh.Size = new System.Drawing.Size(65, 63);
            this.b_cosh.TabIndex = 42;
            this.b_cosh.Text = "Cosh";
            this.b_cosh.UseVisualStyleBackColor = true;
            this.b_cosh.Click += new System.EventHandler(this.b_cosh_Click);
            // 
            // b_x2
            // 
            this.b_x2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_x2.Location = new System.Drawing.Point(558, 73);
            this.b_x2.Name = "b_x2";
            this.b_x2.Size = new System.Drawing.Size(65, 63);
            this.b_x2.TabIndex = 41;
            this.b_x2.Text = "x^2";
            this.b_x2.UseVisualStyleBackColor = true;
            this.b_x2.Click += new System.EventHandler(this.b_x2_Click);
            // 
            // b_sqrt
            // 
            this.b_sqrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_sqrt.Location = new System.Drawing.Point(487, 73);
            this.b_sqrt.Name = "b_sqrt";
            this.b_sqrt.Size = new System.Drawing.Size(65, 63);
            this.b_sqrt.TabIndex = 40;
            this.b_sqrt.Text = "Sqrt";
            this.b_sqrt.UseVisualStyleBackColor = true;
            this.b_sqrt.Click += new System.EventHandler(this.b_sqrt_Click);
            // 
            // b_log
            // 
            this.b_log.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_log.Location = new System.Drawing.Point(416, 73);
            this.b_log.Name = "b_log";
            this.b_log.Size = new System.Drawing.Size(65, 63);
            this.b_log.TabIndex = 39;
            this.b_log.Text = "Log";
            this.b_log.UseVisualStyleBackColor = true;
            this.b_log.Click += new System.EventHandler(this.b_log_Click);
            // 
            // b_pi
            // 
            this.b_pi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b_pi.Location = new System.Drawing.Point(345, 73);
            this.b_pi.Name = "b_pi";
            this.b_pi.Size = new System.Drawing.Size(65, 63);
            this.b_pi.TabIndex = 38;
            this.b_pi.Text = "Pi";
            this.b_pi.UseVisualStyleBackColor = true;
            this.b_pi.Click += new System.EventHandler(this.b_pi_Click);
            // 
            // lblShowOP
            // 
            this.lblShowOP.AutoSize = true;
            this.lblShowOP.Location = new System.Drawing.Point(12, 24);
            this.lblShowOP.Name = "lblShowOP";
            this.lblShowOP.Size = new System.Drawing.Size(0, 13);
            this.lblShowOP.TabIndex = 59;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_Multiply);
            this.groupBox1.Controls.Add(this.button_reset);
            this.groupBox1.Controls.Add(this.button_wielo);
            this.groupBox1.Controls.Add(this.list_wielokrotnosc);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(644, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 339);
            this.groupBox1.TabIndex = 60;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Wielokrotność";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 64;
            this.label1.Text = "Podaj liczbę: ";
            // 
            // txt_Multiply
            // 
            this.txt_Multiply.Location = new System.Drawing.Point(160, 275);
            this.txt_Multiply.Name = "txt_Multiply";
            this.txt_Multiply.Size = new System.Drawing.Size(75, 22);
            this.txt_Multiply.TabIndex = 63;
            // 
            // button_reset
            // 
            this.button_reset.Location = new System.Drawing.Point(160, 303);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(75, 30);
            this.button_reset.TabIndex = 62;
            this.button_reset.Text = "Reset";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click);
            // 
            // button_wielo
            // 
            this.button_wielo.Location = new System.Drawing.Point(6, 303);
            this.button_wielo.Name = "button_wielo";
            this.button_wielo.Size = new System.Drawing.Size(148, 30);
            this.button_wielo.TabIndex = 61;
            this.button_wielo.Text = "Wielokrotność";
            this.button_wielo.UseVisualStyleBackColor = true;
            this.button_wielo.Click += new System.EventHandler(this.button_wielo_Click);
            // 
            // list_wielokrotnosc
            // 
            this.list_wielokrotnosc.FormattingEnabled = true;
            this.list_wielokrotnosc.ItemHeight = 16;
            this.list_wielokrotnosc.Location = new System.Drawing.Point(6, 21);
            this.list_wielokrotnosc.Name = "list_wielokrotnosc";
            this.list_wielokrotnosc.Size = new System.Drawing.Size(148, 276);
            this.list_wielokrotnosc.TabIndex = 0;
            this.list_wielokrotnosc.SelectedIndexChanged += new System.EventHandler(this.list_wielokrotnosc_SelectedIndexChanged);
            // 
            // Kalkulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 421);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblShowOP);
            this.Controls.Add(this.b_x3);
            this.Controls.Add(this.b_dec);
            this.Controls.Add(this.b_sin);
            this.Controls.Add(this.b_sinh);
            this.Controls.Add(this.b_procent);
            this.Controls.Add(this.b_oct);
            this.Controls.Add(this.b_mod);
            this.Controls.Add(this.b_exp);
            this.Controls.Add(this.b_logx);
            this.Controls.Add(this.b_hex);
            this.Controls.Add(this.b_tan);
            this.Controls.Add(this.b_tanh);
            this.Controls.Add(this.b_1x);
            this.Controls.Add(this.b_bin);
            this.Controls.Add(this.b_cos);
            this.Controls.Add(this.b_cosh);
            this.Controls.Add(this.b_x2);
            this.Controls.Add(this.b_sqrt);
            this.Controls.Add(this.b_log);
            this.Controls.Add(this.b_pi);
            this.Controls.Add(this.b_plus);
            this.Controls.Add(this.b_9);
            this.Controls.Add(this.b_8);
            this.Controls.Add(this.b_7);
            this.Controls.Add(this.b_podziel);
            this.Controls.Add(this.b_wynik);
            this.Controls.Add(this.b_kropka);
            this.Controls.Add(this.b_0);
            this.Controls.Add(this.b_mnozenie);
            this.Controls.Add(this.b_3);
            this.Controls.Add(this.b_2);
            this.Controls.Add(this.b_1);
            this.Controls.Add(this.b_minus);
            this.Controls.Add(this.b_6);
            this.Controls.Add(this.b_5);
            this.Controls.Add(this.b_4);
            this.Controls.Add(this.b_plusminus);
            this.Controls.Add(this.b_C);
            this.Controls.Add(this.b_CE);
            this.Controls.Add(this.b_strzalka);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Kalkulator";
            this.Text = "Kalkulator";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rodzajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zwykłyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programistyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem konwersjaJednostekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiplicationToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button b_strzalka;
        private System.Windows.Forms.Button b_CE;
        private System.Windows.Forms.Button b_C;
        private System.Windows.Forms.Button b_plusminus;
        private System.Windows.Forms.Button b_minus;
        private System.Windows.Forms.Button b_6;
        private System.Windows.Forms.Button b_5;
        private System.Windows.Forms.Button b_4;
        private System.Windows.Forms.Button b_mnozenie;
        private System.Windows.Forms.Button b_3;
        private System.Windows.Forms.Button b_2;
        private System.Windows.Forms.Button b_1;
        private System.Windows.Forms.Button b_podziel;
        private System.Windows.Forms.Button b_wynik;
        private System.Windows.Forms.Button b_kropka;
        private System.Windows.Forms.Button b_0;
        private System.Windows.Forms.Button b_plus;
        private System.Windows.Forms.Button b_9;
        private System.Windows.Forms.Button b_8;
        private System.Windows.Forms.Button b_7;
        private System.Windows.Forms.Button b_x3;
        private System.Windows.Forms.Button b_dec;
        private System.Windows.Forms.Button b_sin;
        private System.Windows.Forms.Button b_sinh;
        private System.Windows.Forms.Button b_procent;
        private System.Windows.Forms.Button b_oct;
        private System.Windows.Forms.Button b_mod;
        private System.Windows.Forms.Button b_exp;
        private System.Windows.Forms.Button b_logx;
        private System.Windows.Forms.Button b_hex;
        private System.Windows.Forms.Button b_tan;
        private System.Windows.Forms.Button b_tanh;
        private System.Windows.Forms.Button b_1x;
        private System.Windows.Forms.Button b_bin;
        private System.Windows.Forms.Button b_cos;
        private System.Windows.Forms.Button b_cosh;
        private System.Windows.Forms.Button b_x2;
        private System.Windows.Forms.Button b_sqrt;
        private System.Windows.Forms.Button b_log;
        private System.Windows.Forms.Button b_pi;
        private System.Windows.Forms.Label lblShowOP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_Multiply;
        private System.Windows.Forms.Button button_reset;
        private System.Windows.Forms.Button button_wielo;
        private System.Windows.Forms.ListBox list_wielokrotnosc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem wyjścieToolStripMenuItem;
    }
}

